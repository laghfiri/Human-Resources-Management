import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClientModule} from '@angular/common/http';
import {Http} from '@angular/http';
import { map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FileService {

  constructor(public httpclient:Http) { }
  postFile(fileToUpload: File): Observable<boolean> {
    const endpoint = 'assets/img/my.png';
    const formData: FormData = new FormData();
    formData.append('fileKey', fileToUpload, fileToUpload.name);
    return this.httpclient
      .post(endpoint, formData, )
      .pipe(map(() => { return true; }))

  }
}
