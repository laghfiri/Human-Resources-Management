import { employee } from './../app/model/model.employee';
import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import { map} from 'rxjs/operators';



@Injectable()
export class EmployeeService {


  constructor(public http: Http) {

  }

  getEmployes(motCle:String,page:number,size:number) {
    return this.http.get('http://localhost:8080/chercherPersonnes?mc='+motCle+'&page='+page+'&size='+size)
      .pipe(map(resp => resp.json()));
  }

  saveEmployes(employee:employee){
    return this.http.post('http://localhost:8080/personne',employee).pipe(map(resp => resp.json()));

  }
  suppEmployee(Matricule:any){
    return this.http.delete('http://localhost:8080/personne/'+Matricule).pipe(map(resp => resp.json()));
  }
  modiEmployee(mat:number,employee:employee){
    return this.http.put('http://localhost:8080/personne/'+mat,employee).pipe(map(resp => resp.json()));
  }
}
