import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import { map} from 'rxjs/operators';
import {Contact} from '../app/model/model.contacts';





@Injectable()

export class ContactsService {

  constructor(public http: Http) {

  }

  getContacts(motCle:String,page:number,size:number) {
    return this.http.get('http://localhost:8080/chercherContacts?mc='+motCle+'&page='+page+'&size='+size).pipe(map(resp => resp.json()));
  }

  saveContact(contact:Contact){
    return this.http.post('http://localhost:8080/contacts',contact).pipe(map(resp => resp.json()));

  }
}
